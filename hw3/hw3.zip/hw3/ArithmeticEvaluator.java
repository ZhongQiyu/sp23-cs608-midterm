import hw3.Stack;

public class ArithmeticCalculator {
	
	private static final String ADD = "+";
	private static final String SUB = "-";
	private static final String MUL = "*";
	private static final String DIV = "/";
	private static final String LTP = "(";
	private static final String RTP = ")";
	private Stack<String> numbers;
	private Stack<String> operators;

	public static void main(String[] args) {
		
	}

}